## Buzzier Villages (v1.0)

Adds the following:

- Apiary structures for every village type in ReStruc

Compatibilty:

- Environmental compat pack: Switches around the Swamp Apiarist's House to use willow wood, cattails and mud. REQUIRES EXTRA DOWNLOAD

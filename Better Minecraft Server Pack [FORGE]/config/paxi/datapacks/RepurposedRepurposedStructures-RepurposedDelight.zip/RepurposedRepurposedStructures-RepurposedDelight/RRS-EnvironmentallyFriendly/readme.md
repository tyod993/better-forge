## Environmentally Friendly (v2.0)

Adds the following:

- Changes the Flower Forest Temple to use Wisteria Wood and Environmental flowers!
- Changes the Swamp Dungeon to use Mud on its base! It also has a tiny chance for a Slabfish spawner.

Compatibility:

- Switches BB pack's Swamp Apiary to use willow wood, mud and cattails.
- Switches FD pack's Swamp Compost Pile to use willow wood, mud and cattails.

## Environmentally Friendly (v1.1)

Adds the following:

- Switches BB pack's Swamp Apiary to use willow wood, mud and cattails.
- Switches FD pack's Swamp Compost Pile to use willow wood, mud and cattails.
